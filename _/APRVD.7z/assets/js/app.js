/*! app.js | 2019 @yamoo9 */

;(function() {
  'use strict'

})()

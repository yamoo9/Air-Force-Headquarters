<template>
  <div class="md-layout md-alignment-center" style="margin: 4em 0">

    <!-- 상단 내비게이션 -->
    <md-toolbar class="fixed-toolbar" elevation="14">
      <md-button @click="showFeedSidePanel = true" class="md-icon-button">
        <md-icon>menu</md-icon>
      </md-button>

      <nuxt-link
        class="md-primary md-title" to="/"
        style="color: #f1453d; text-decoration: none; font-weight: bold"
      >
        <img src="~/assets/bookmark.png" alt style="max-height: 30px;">
        <span class="logo-text">News&middot;mark</span>
      </nuxt-link>

      <div class="md-toolbar-section-end">
        <template v-if="isAuthenticated">
          <md-button>
            <md-avatar>
              <img :src="user.avatar" :alt="user.email" style="width: 30px; height: auto; border-radius: 15px;">
            </md-avatar>
            {{ user.email }}
          </md-button>
          <md-button @click="logoutUser">로그아웃</md-button>
        </template>
        <template v-else>
          <md-button to="/login">로그인</md-button>
          <md-button to="/register">회원가입</md-button>
        </template>
        <md-button class="md-primary" @click="showSearchDialog = true">뉴스 검색</md-button>
        <md-button class="md-accent" @click="showCategoriesPanel = true">카테고리</md-button>
      </div>
    </md-toolbar>

    <!-- 검색 다이얼로그 -->
    <md-dialog :md-active.sync="showSearchDialog">
      <md-dialog-title>뉴스 검색</md-dialog-title>
      <div class="md-layout" style="padding: 1em">
        <md-field>
          <label for="keywords">검색 키워드</label>
          <md-input
            v-model="query"
            placeholder="검색 시 AND, OR, NOT을 입력해 키워드를 구분하여 검색할 수 있습니다."
            id="keywords"
            max-length="30"
          ></md-input>
        </md-field>
        <div class="md-title">검색 범위</div>
        <md-datepicker v-model="fromDate" md-immediately>
          <label>시작 날짜 (선택사항)</label>
        </md-datepicker>
        <md-datepicker v-model="toDate" md-immediately>
          <label>종료 날짜 (선택사항)</label>
        </md-datepicker>
        <md-field>
          <label for="sortBy">정렬 (선택사항)</label>
          <md-select id="sortBy" v-model="sortBy" md-dense>
            <md-option value="publishedAt">최신 순 (기본 값)</md-option>
            <md-option value="relevancy">연관 순</md-option>
            <md-option value="popularity">인기 순</md-option>
          </md-select>
        </md-field>
      </div>

      <md-dialog-actions>
        <md-button class="md-accent" @click="showSearchDialog = false">닫기</md-button>
        <md-button class="md-primary" @click="searchHeadlines">검색</md-button>
      </md-dialog-actions>
    </md-dialog>

    <!-- 사용자 뉴스 피드 사이드바 (왼쪽 사이드바) -->
    <md-drawer md-fixed :md-active.sync="showFeedSidePanel">
      <md-toolbar md-elevation="1">
        <span class="md-title">사용자 피드</span>
      </md-toolbar>

      <!-- 국가 선택 -->
      <md-progress-bar v-if="isLoading" md-mode="indeterminate"/>
      <md-field>
        <label for="country">뉴스 리소스 국가 선택</label>
        <md-select
          @input="changeCountry"
          :value="country"
          name="country"
          id="country"
        >
          <md-option value="kr">대한민국</md-option>
          <md-option value="us">미국</md-option>
          <md-option value="jp">일본</md-option>
        </md-select>
      </md-field>

      <!-- 피드 콘테츠 개수가 0일 때 화면에 출력 (로그인 안한 경우) -->
      <md-empty-state
        v-if="feed.length === 0 && !user"
        class="md-primary"
        md-icon="bookmarks"
        md-label="즐겨찾기가 없습니다."
        md-description="사용자 계정 로그인을 해야 북마크가 표시됩니다."
      >
        <md-button to="/login" class="md-primary md-raised">로그인</md-button>
      </md-empty-state>

      <!-- 피드 콘테츠 개수가 0일 때 화면에 출력 (로그인 한 경우) -->
      <md-empty-state
        v-else-if="feed.length === 0"
        class="md-accent"
        md-icon="bookmark_outline"
        md-label="즐겨찾기가 없습니다."
        md-description="즐겨찾기 할 뉴스를 선택하면 이 곳에 추가됩니다."
      ></md-empty-state>

      <!-- 피드 콘텐츠 개수가 1개 이상 일 경우 화면에 출력 (로그인 한 사용자) -->
      <md-list v-else class="md-triple-line">
        <md-list-item v-for="(headline,i) in feed" :key="i">
          <md-avatar>
            <img :src="headline.urlToImage" :alt="headline.title">
          </md-avatar>
          <div class="md-list-item-text">
            <span>
              <a :href="headline.url" target="_blank">{{ headline.title }}</a>
            </span>
            <span>{{ headline.source.name }}</span>
            <a style="margin-top: 6px;" href @click.prevent="saveHeadline(headline)">댓글</a>
          </div>
          <md-button
            class="md-icon-button md-list-action"
            style="margin-top: 7px;"
            @click="removeHeadlineFromFeed(headline)"
            aria-label="제거" title="제거"
          >
            <md-icon class="md-accent" aria-hidden="true">delete</md-icon>
          </md-button>
          <md-divider class="md-inset"></md-divider>
        </md-list-item>
      </md-list>
    </md-drawer>

    <!-- 카테고리 사이드바 (오른쪽 사이드바) -->
    <md-drawer class="md-right" md-fixed :md-active.sync="showCategoriesPanel">
      <md-toolbar :md-elevation="1">
        <span class="md-title">뉴스 카테고리</span>
      </md-toolbar>
      <md-progress-bar v-if="isLoading" md-mode="indeterminate"/>
      <md-list>
        <md-subheader class="md-primary">카테고리 선택</md-subheader>
        <md-list-item
          v-for="(newsCategory,i) in newsCategories"
          :key="i"
          @click="loadCategory(newsCategory.path)"
        >
          <md-icon
            :class="[ newsCategory.path === category ? 'md-primary' : '' ]"
          >{{ newsCategory.icon }}</md-icon>
          <span class="md-list-item-text">{{ newsCategory.name }}</span>
        </md-list-item>
      </md-list>
    </md-drawer>

    <!-- 뉴스 리스트 -->
    <div class="md-layout-item md-size-95">
      <md-content
        class="md-layout md-gutter"
        style="padding: 1em; background: transparent"
      >
        <ul
          class="md-layout-item md-large-size-25 md-medium-size-33 md-small-size-50 md-xsmall-size-100"
          v-for="headline in headlines"
          style="list-style: none; padding-left: 0"
          :key="headline.id"
        >
          <li>
            <md-card style="margin-top: 1em;" md-with-hover>
              <md-ripple>
                <md-card-media md-ratio="16:9">
                  <img :src="headline.urlToImage" :alt="headline.title">
                </md-card-media>
                <md-card-header>
                  <div class="md-title">
                    <a :href="headline.url" target="_blank">{{ headline.title }}</a>
                  </div>
                  <div style="margin: 10px 0">
                    <a
                      href
                      @click.prevent="loadSource(headline.source.id)"
                    >{{ headline.source.name }}</a>
                    <md-icon class="small">book</md-icon>
                  </div>
                  <div class="md-subhead" v-if="headline.author">
                    {{ headline.author }}
                    <md-icon class="small-icon">face</md-icon>
                  </div>
                  <div class="md-subhead">
                    {{ headline.publishedAt | publishedTimeToNow }}
                    <md-icon class="small-icon">alarm</md-icon>
                  </div>
                </md-card-header>
                <md-card-actions>
                  <md-button
                    @click="toogleHeadlineFeed(headline)"
                    class="md-icon-button"
                    :class="isInFeed(headline.title)"
                  >
                    <md-icon>bookmark</md-icon>
                  </md-button>
                  <md-button
                    :href="`/headlines/${headline.slug}`"
                    @click.prevent="saveHeadline(headline)"
                    class="md-icon-button"
                  >
                    <md-icon>message</md-icon>
                  </md-button>
                </md-card-actions>
              </md-ripple>
            </md-card>
          </li>
        </ul>
      </md-content>
    </div>

    <!-- 스넥바 -->
    <md-snackbar :md-active.sync="showSnackbar" md-persistent>
      <!-- <span>북마크 기능을 사용하려면 사용자 계정으로 로그인 해야 합니다.</span> -->
      <span>{{ snackbarMsg }}</span>
      <md-button class="md-primary" @click="showSnackbar = false">닫기</md-button>
    </md-snackbar>

  </div>
</template>

<script>
import { mapGetters } from "vuex";
export default {
  name: "Home",
  async fetch({ app, store, query }) {
    await store.dispatch(
      "loadHeadlines",
      `/api/top-headlines?country=${store.getters.country}&category=${
        store.getters.category
      }`
    );
    await store.dispatch("loadUserFeed");
  },
  watch: {
    country(value, oldValue) {
      this.$store.dispatch(
        "loadHeadlines",
        `/api/top-headlines?country=${this.country}&category=${this.category}`
      );
    }
  },
  data: () => ({
    showCategoriesPanel: false,
    showFeedSidePanel: false,
    showSnackbar: false,
    showSearchDialog: false,
    snackbarMsg: "",
    query: "",
    fromDate: "",
    toDate: "",
    sortBy: "",
    newsCategories: [
      { name: "톱 헤드라인", path: "", icon: "today" },
      { name: "테크놀로지", path: "technology", icon: "keyboard" },
      { name: "비즈니스", path: "business", icon: "business_center" },
      { name: "엔터테인먼트", path: "entertainment", icon: "weekend" },
      { name: "건강", path: "health", icon: "fastfood" },
      { name: "과학", path: "science", icon: "fingerprint" },
      { name: "스포츠", path: "sports", icon: "golf_course" }
    ]
  }),
  computed: {
    ...mapGetters([
      "headlines",
      "feed",
      "category",
      "isLoading",
      "country",
      "user",
      "isAuthenticated",
      "source"
    ]),
  },
  methods: {
    async loadCategory(category) {
      this.$store.commit("setCategory", category);
      await this.$store.dispatch(
        "loadHeadlines",
        `/api/top-headlines?country=${this.country}&category=${this.category}`
      );
    },
    changeCountry(country) {
      this.$store.commit("setCountry", country);
    },
    async addHeadlineToFeed(headline) {
      if (this.user) {
        await this.$store.dispatch("addHeadlineToFeed", headline);
      } else {
        this.showSnackbar = true;
        this.snackbarMsg =
          "북마크 기능을 사용하려면 사용자 계정으로 로그인해야 합니다.";
      }
    },
    async removeHeadlineFromFeed(headline) {
      await this.$store.dispatch("removeHeadlineFromFeed", headline);
    },
    toogleHeadlineFeed(headline) {
      const title = headline.title;
      if (this.feed.findIndex(headline => headline.title === title) > -1) {
        this.removeHeadlineFromFeed(headline);
      } else {
        this.addHeadlineToFeed(headline)
      }
    },
    async saveHeadline(headline) {
      await this.$store.dispatch("saveHeadline", headline).then(() => {
        this.$router.push(`/headlines/${headline.slug}`);
      });
    },
    async loadSource(sourceId) {
      if (sourceId) {
        this.$store.commit("setSource", sourceId);
        await this.$store.dispatch(
          "loadHeadlines",
          `/api/top-headlines?sources=${this.source}`
        );
      } else {
        this.showSnackbar = true;
        this.snackbarMsg = "죄송합니다. 선택한 뉴스 제공사의 뉴스를 리스트할 수 없습니다.";
      }
    },
    async searchHeadlines() {
      await this.$store.dispatch(
        "loadHeadlines",
        `/api/everything?q=${this.query}&
          from=${this.dateToISOString(this.fromDate)}&
          to=${this.dateToISOString(this.toDate)}&
          sortBy=${this.sortBy}`);
      this.showSearchDialog = false;
    },
    dateToISOString(date) {
      if (date) { return new Date(date).toISOString(); }
    },
    logoutUser() {
      this.$store.dispatch("logoutUser");
    },
    isInFeed(title) {
      const inFeed = this.feed.findIndex(headline => headline.title === title) > -1;
      return inFeed ? "md-accent" : "";
    }
  }
};
</script>

<style lang="sass" scoped>
.md-icon
  font-size: 18px !important

.fixed-toolbar
  position: fixed
  top: 0
  z-index: 5
</style>
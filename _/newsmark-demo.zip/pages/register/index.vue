<template>
  <div id="register">
    <div class="md-layout md-alignment-center-center" style="height: 100vh;">

      <md-card class="md-layout-item md-size-50">
        <md-card-header>
          <h1 class="md-title">회원가입</h1>
        </md-card-header>

        <!-- 회원가입 폼 -->
        <form @submit.prevent="validateForm" novalidate>
          <md-card-content>
            <md-field md-clearable :class="getValidationClass('email')">
              <label for="email">이메일</label>
              <md-input
                :disabled="isLoading"
                type="email"
                v-model="register.email"
                id="email"
                autocomplete="email"
              />
              <span
                class="md-error"
                v-if="!$v.register.email.required"
              >이메일 입력은 필수입니다.</span>
              <span
                class="md-error"
                v-else-if="!$v.register.email.email"
              >이메일 형식이 잘못되었습니다.</span>
            </md-field>
            <md-field :class="getValidationClass('password')">
              <label for="password">패스워드</label>
              <md-input
                :disabled="isLoading"
                type="password"
                v-model="register.password"
                id="password"
                autocomplete="password"
              />
              <span
                class="md-error"
                v-if="!$v.register.password.required"
              >패스워드 입력은 필수입니다.</span>
              <span
                class="md-error"
                v-else-if="!$v.register.password.minLength"
              >패스워드는 6자리 이상 요구됩니다.</span>
              <span
                class="md-error"
                v-else-if="!$v.register.password.maxLength"
              >패스워드가 20자리 이하로 요구됩니다.</span>
            </md-field>
          </md-card-content>
          <md-card-actions>
            <md-button to="/login">로그인</md-button>
            <md-button
              class="md-primary md-raised"
              type="submit"
              :disabled="isLoading"
            >가입</md-button>
          </md-card-actions>
        </form>

        <md-snackbar :md-active.sync="isAuthenticated">
          {{ register.email }} 계정으로 가입이 성공적으로 이루어졌습니다!
        </md-snackbar>
      </md-card>

      <!-- 뒤로가기 버튼 -->
      <md-button
        class="md-fab md-fab-bottom-right md-fixed md-primary"
        @click="$router.go(-1)"
      >
        <md-icon>arrow_back</md-icon>
      </md-button>

    </div>
  </div>
</template>

<script>
// 참고: https://vuelidate.netlify.com/#sub-basic-usage
import { validationMixin } from "vuelidate";
import {
  required,
  minLength,
  maxLength,
  email
} from "vuelidate/lib/validators";

export default {
  name: "Register",
  // 참고: https://nuxtjs.org/api/pages-middleware#the-middleware-property
  middleware: "auth",
  mixins: [validationMixin],
  data: () => ({
    register: {
      email: "",
      password: ""
    }
  }),
  // 참고: https://vuelidate.netlify.com/#sub-basic-form
  validations: {
    register: {
      email: {
        required,
        email
      },
      password: {
        required,
        minLength: minLength(6),
        maxLength: maxLength(20)
      }
    }
  },
  computed: {
    isLoading() {
      return this.$store.getters.isLoading;
    },
    isAuthenticated() {
      return this.$store.getters.isAuthenticated;
    }
  },
  watch: {
    isAuthenticated(value, oldValue) {
      if (value) {
        setTimeout(() => this.$router.push("/"), 2000);
      }
    }
  },
  methods: {
    validateForm() {
      // 참고:
      // https://vuelidate.netlify.com/#a-p-i
      // https://vuelidate.netlify.com/#sub-v-methods
      this.$v.$touch();
      if (!this.$v.$invalid) {
        this.registerUser();
      }
    },
    registerUser() {
      this.$store.dispatch("authenticateUser", {
        ...this.register,
        action: "register",
        returnSecureToken: true
      });
    },
    getValidationClass(fieldName) {
      const field = this.$v.register[fieldName];
      if (field) {
        return {
          "md-invalid": field.$invalid && field.$dirty
        };
      }
    }
  }
};
</script>
// 참고: https://nuxtjs.org/api/pages-middleware#the-middleware-property
export default ({store, redirect}) => {
  if (store.getters.isAuthenticated) {
    redirect('/');
  }
};
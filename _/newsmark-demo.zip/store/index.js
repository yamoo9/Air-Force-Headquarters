import Vuex from 'vuex';
import md5 from 'md5';
import db from '~/plugins/firestore';
import slugify from 'slugify';
import { saveUserData, clearUserData } from '~/utils';
import newsMockUrl from '~/assets/news-mock.jpg';

const createStore = () => {
  return new Vuex.Store({
    state: {
      headlines: [],
      headline: null,
      feed: [],
      country: 'kr',
      category: '',
      isLoading: false,
      token: '',
      user: null,
      source: '',
    },
    mutations: {
      setHeadlines(state, articles) {
        state.headlines = articles;
      },
      setHeadline(state, headline) {
        state.headline = headline;
      },
      setCategory(state, category) {
        state.category = category;
      },
      setLoading(state, loadingState) {
        state.isLoading = loadingState;
      },
      setCountry(state, country) {
        state.country = country;
      },
      setToken(state, token) {
        state.token = token;
      },
      setUser(state, user) {
        state.user = user;
      },
      clearToken: state => (state.token = ''),
      clearUser: state => (state.user = null),
      clearFeed: state => (state.feed = []),
      setFeed(state, headlines) {
        state.feed = headlines;
      },
      setSource(state, source) {
        state.source = source;
      }
    },
    actions: {
      async loadHeadlines({commit}, apiUrl) {
        commit('setLoading', true);
        const { articles } = await this.$axios.$get(apiUrl);
        // 참고: https://www.npmjs.com/package/slugify#options
        const headlines = articles.map(article => {
          const slug = slugify(article.title, {
            replacement: '-',               // 공백 대체 문자 설정
            remove: /[\[\],`*+~.()'"!:@]/g, // 제거할 문자 설정
            lower: true                     // 소문자 화 설정
          });
          if (!article.urlToImage) {
            article.urlToImage = newsMockUrl;
          }
          const headline = { ...article, slug };
          return headline;
        });
        commit('setLoading', false);
        commit('setHeadlines', headlines);
      },
      async loadHeadline({ commit }, headlineSlug) {
        const headlineRef = db.collection('headlines').doc(headlineSlug);
        const commentsRef = db.collection(`headlines/${headlineSlug}/comments`).orderBy('likes', 'desc');

        let loadedHeadline = {};

        await headlineRef.get().then(async doc => {
          if (doc.exists) {
            loadedHeadline = doc.data();
            await commentsRef.get().then(querySnapshot => {
              if (querySnapshot.empty) {
                commit('setHeadline', loadedHeadline);
              }
              let loadedComments = [];
              querySnapshot.forEach(doc => {
                loadedComments.push(doc.data());
                loadedHeadline['comments'] = loadedComments;
                commit('setHeadline', loadedHeadline);
              });
            });
          }
        });
      },
      async authenticateUser({commit}, userData) {
        commit('setLoading', true);
        try {
          const authUserData = await this.$axios.$post(`/${userData.action}/`, {
            email: userData.email,
            password: userData.password,
            returnSecureToken: userData.returnSecureToken,
          });

          let user; // 가입 및 로그인 사용자 정보 참조 변수

          // 회원 가입 액션
          if (userData.action === 'register') {
            const avatar = `https://gravatar.com/avatar/${md5(authUserData.email)}?d=identicon`;
            user = { email: authUserData.email, avatar };
            await db.collection('users').doc(userData.email).set(user);
          }
          // 로그인 액션
          else {
            const loginRef = db.collection('users').doc(userData.email);
            // console.log(loginRef);
            const loggedInUser = await loginRef.get();
            user = loggedInUser.data();
          }

          commit('setUser', user);
          commit('setToken', authUserData.idToken);
          commit('setLoading', false);

          saveUserData(authUserData, user);

        } catch (error) {
          console.error(error);
          commit('setLoading', false);
        }
      },
      async addHeadlineToFeed({ commit, getters }, headline) {
        // Firestore segment 오류 해결을 위해 정규표현식으로 [] 문자 제거
        headline.title = headline.title.replace(/^\[(.*?)\]/, '');
        const feedRef = db.collection(`users/${getters.user.email}/feed`).doc(headline.title);
        await feedRef.set(headline);
      },
      async loadUserFeed({state, commit}) {
        if (state.user) {
          const feedRef = db.collection(`users/${state.user.email}/feed`);
          // await feedRef.get().then(querySnapShot => {
          // 참고: https://firebase.google.com/docs/firestore/query-data/listen
          await feedRef.onSnapshot(doc => {
            let headlines = [];
            doc.forEach(doc => headlines.push(doc.data()));
            commit('setFeed', headlines);
          });
        }
      },
      async removeHeadlineFromFeed({state, commit}, headline) {
        const headlineRef = db.collection(`users/${state.user.email}/feed`).doc(headline.title);
        await headlineRef.delete();
      },
      async saveHeadline({state}, headline) {
        const headlineRef = db.collection(`headlines`).doc(headline.slug);
        let headlineId;
        await headlineRef.get().then(doc => {
          if (doc.exists) { headlineId = doc.id; }
        });
        if (!headlineId) {
          await headlineRef.set(headline);
        }
      },
      async sendComment({ state, commit }, comment) {
        const commentsRef = db.collection(`headlines/${state.headline.slug}/comments`);
        commit('setLoading', true);
        await commentsRef.doc(comment.id).set(comment);
        await commentsRef.orderBy('likes', 'desc').get().then(querySnapshot => {
          let comments = [];
          querySnapshot.forEach(doc => {
            comments.push(doc.data());
            const updateHeadline = { ...state.headline, comments };
            commit('setHeadline', updateHeadline);
          });
        });
        commit('setLoading', false);
      },
      async likeComment({ state, commit }, commentId) {
        const commentsRef = db.collection(`headlines/${state.headline.slug}/comments`).orderBy('likes', 'desc');
        const likeCommentRef = db.collection(`headlines`).doc(state.headline.slug).collection('comments').doc(commentId);
        await likeCommentRef.get().then(doc => {
          const preLikes = doc.data().likes;
          const curLikes = preLikes + 1;
          likeCommentRef.update({
            likes: curLikes
          });
        });
        await commentsRef.onSnapshot(querySnapshot => {
          let loadedComments = [];
          querySnapshot.forEach(doc => {
            loadedComments.push(doc.data());
            const updateHeadline = {
              ...state.headline,
              comments: loadedComments
            };
            commit('setHeadline', updateHeadline);
          });
        });
      },
      setLogoutTimer({dispatch}, timeToLogout) {
        setTimeout(() => {
          dispatch('logoutUser')
        }, timeToLogout);
      },
      logoutUser({commit}) {
        commit('clearToken');
        commit('clearUser');
        commit('clearFeed');
        clearUserData();
      },
    },
    getters: {
      headlines       : state => state.headlines,
      headline        : state => state.headline,
      feed            : state => state.feed,
      category        : state => state.category,
      country         : state => state.country,
      isLoading       : state => state.isLoading,
      isAuthenticated : state => !!state.token,
      user            : state => state.user,
      source          : state => state.source,
    }
  });
};

export default createStore;
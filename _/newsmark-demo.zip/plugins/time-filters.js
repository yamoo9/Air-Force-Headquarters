import Vue from 'vue';
import { formatRelative, distanceInWordsToNow } from 'date-fns';
import ko from 'date-fns/locale/ko';

const ellipsis = (value, limit=300) => {
  return `${value.toString().trim().slice(0, limit)} ......`;
};

// 참고: https://date-fns.org/v1.30.1/docs/distanceInWordsToNow
const publishedTimeToNow = time => {
  return distanceInWordsToNow(time, {
    locale: ko
  });
};

const commentTimeToNow = timestamp => {
  return distanceInWordsToNow(timestamp, {
    locale: ko,
    includeSeconds: true,
  });
};

Vue.filter('ellipsis', ellipsis);
Vue.filter('publishedTimeToNow', publishedTimeToNow);
Vue.filter('commentTimeToNow', commentTimeToNow);
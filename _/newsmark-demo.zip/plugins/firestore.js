import firebase from 'firebase/app';
import 'firebase/firestore';

if (!firebase.apps.length) {
  const config = {
    apiKey: "AIzaSyDUTmyoIJousgR_ChVXuJK_xNBeJvWvY_U",
    authDomain: "fir-auth-with-vue.firebaseapp.com",
    databaseURL: "https://fir-auth-with-vue.firebaseio.com",
    projectId: "fir-auth-with-vue",
    storageBucket: "fir-auth-with-vue.appspot.com",
    messagingSenderId: "472331820685"
  };

  firebase.initializeApp(config);

  // firebase.firestore().settings({
    // 기본 설정이므로 아래 설정은 추가할 필요가 없음
    // timestampsInSnapshots: true
  // });
}

const db = firebase.firestore();

export default db;
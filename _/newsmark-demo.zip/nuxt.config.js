import pkg from './package'

export default {
  mode: 'spa',

  /*
  ** 라우터 설정
  */
  router: {
    middleware: 'check-auth'
  },

  /*
  ** 페이지 헤더 설정
  */
  head: {
    title: 'Newsmark | 뉴스 북마크 서비스',
    meta: [
      { charset: 'utf-8' },
      { name: 'viewport', content: 'width=device-width, initial-scale=1' },
      { hid: 'description', name: 'description', content: pkg.description }
    ],
    link: [
      { rel: 'icon', type: 'image/x-icon', href: '/favicon.png' },
      { rel: 'stylesheet', href: 'https://fonts.googleapis.com/css?family=Roboto:400,500,700,400italic|Material+Icons' },
    ]
  },

  /*
  ** 프로그래스바 사용저 정의
  */
  loading: { color: '#f1453d', height: '2px' },

  /*
  ** 글로벌 CSS
  */
  css: [
    'vue-material/dist/vue-material.min.css',
    '~/assets/theme.scss',
  ],

  /*
  ** 플러그인
  */
  plugins: [
    '~/plugins/vue-router-fix',
    '~/plugins/time-filters',
    '~/plugins/vue-material',
    '~/plugins/firestore',
    '~/plugins/newsApi',
  ],

  /*
  ** Nuxt.js 모듈
  */
  modules: [
    // 참고: https://axios.nuxtjs.org/usage
    '@nuxtjs/axios',
    // 참고: https://axios.nuxtjs.org/options#proxy
    '@nuxtjs/proxy'
  ],
  /*
  ** Axios 모듈 설정
  */
  axios: {
    credentials: true,
    proxy: true,
  },

  /*
  ** proxy 모듈 설정
  */
  proxy: {
    '/api/': {
      target: 'https://newsapi.org/v2/',
      pathRewrite: { '^/api/': '' }
    },
    '/register/': {
      target: 'https://www.googleapis.com/identitytoolkit/v3/relyingparty/signupNewUser?key=AIzaSyDUTmyoIJousgR_ChVXuJK_xNBeJvWvY_U',
      pathRewrite: { '^/register/': '' }
    },
    '/login/': {
      target: 'https://www.googleapis.com/identitytoolkit/v3/relyingparty/verifyPassword?key=AIzaSyDUTmyoIJousgR_ChVXuJK_xNBeJvWvY_U',
      pathRewrite: { '^/login/': '' }
    }
  },

  /*
  ** proxy 모듈 설정
  */
  env: {
    NEWS_API_KEY: 'e8078a1cf5304d95a584d075e031c835',
    FIREBASE_API_KEY: 'AIzaSyDUTmyoIJousgR_ChVXuJK_xNBeJvWvY_U'
  },

  /*
  ** 빌드 설정
  */
  build: {
    /*
    ** Webpack 확장
    */
    extend(config, ctx) {
    }
  }

}
